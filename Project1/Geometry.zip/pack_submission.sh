#!/bin/bash

python task1.py --alpha 45 --beta 30 --gamma 50
python task2.py

python helper.py --ubit $1